package src.view;

import javax.swing.*;

// TODO 영화 상영시간
public class MovieTime_View extends JPanel {
}
