package src.view;

import javax.swing.*;

//TODO
//회원가입 뷰
public class MemberView extends JPanel {
}
