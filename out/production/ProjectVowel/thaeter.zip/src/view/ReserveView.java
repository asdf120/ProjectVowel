package src.view;

import javax.swing.*;

//TODO 예매 뷰 포스터 보이게하고 시간 클릭하면 ReserveView2로 넘어감
public class ReserveView extends JPanel {
}
