package src.model;

public class MemberDao {
}
