package movie.view;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SeatView extends JFrame{


    public SeatView(){

    }
}
